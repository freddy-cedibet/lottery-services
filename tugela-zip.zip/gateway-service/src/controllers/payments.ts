import {catchErrors} from "../errors";

export const getAll =
    catchErrors(async (req, res) => {

        // const paymentResponse = await paymentService.run()

        return res.respond({
            data: {}
        });
    })


export const get =
    catchErrors(async (req, res) => {

        // const paymentResponse = await paymentService.run()

        return res.respond({
            data: {}
        });
    })

export const update =
    catchErrors(async (req, res) => {

        // const paymentResponse = await paymentService.run()

        return res.respond({
            data: {}
        });
    })

export const deleteItem =
    catchErrors(async (req, res) => {

        // const paymentResponse = await paymentService.run()

        return res.respond({
            data: {}
        });
    })
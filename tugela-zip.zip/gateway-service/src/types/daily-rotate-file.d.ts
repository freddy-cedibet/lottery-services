declare module 'winston-daily-rotate-file';

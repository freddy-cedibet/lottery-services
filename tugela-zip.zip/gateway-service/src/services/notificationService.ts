
const sendEmailNotification = (emailDetails: string) => {
    // logic to send email notification
};

const sendSMSNotification = (smsDetails: string) => {
    // logic to send SMS notification
    //another logic
    //more logic
    //more logic
    //more logic
};

module.exports = { sendEmailNotification, sendSMSNotification };

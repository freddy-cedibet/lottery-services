import * as users from './controllers/users';
import * as payments from './controllers/payments';



export const attachPublicRoutes = (app: any): void => {
    //users
    app.get('/api/v1/users', users.getAll)
    app.get('/api/v1/users/:id', users.get)
    app.post('/api/v1/users', users.get)
    app.patch('/api/v1/users/:id', users.update)
    app.delete('/api/v1/users/:id', users.deleteItem)


    //payments
    app.get('/api/v1/payments', payments.getAll)
    app.get('/api/v1/payments/:id', payments.get)
    app.post('/api/v1/payments', payments.get)
    app.patch('/api/v1/payments/:id', payments.update)
    app.delete('/api/v1/payments/:id', payments.update)

}



const sendEmailNotification = (emailDetails) => {
    // logic to send email notification
};

const sendSMSNotification = (smsDetails) => {
    // logic to send SMS notification
    //another logic
    //more logic
    //more logic
    //more logic
};

module.exports = { sendEmailNotification, sendSMSNotification };
